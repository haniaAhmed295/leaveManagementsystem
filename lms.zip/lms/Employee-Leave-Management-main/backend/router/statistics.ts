import express from "express";

export default (router: express.Router) => {};
