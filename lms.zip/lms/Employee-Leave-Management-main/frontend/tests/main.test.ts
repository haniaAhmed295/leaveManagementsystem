import { it, expect, describe } from "vitest";

describe("group", () => {
    it("should", () => {
        expect(1).toBeTruthy();
    });
});
