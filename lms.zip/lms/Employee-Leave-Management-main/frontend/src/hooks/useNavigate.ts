const useNavigate = (to: string) => {
    return (window.location.href = to);
};

export default useNavigate;
