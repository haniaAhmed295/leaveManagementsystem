export enum SignType {
    Login = "/login",
    Register = "/register",
    Reset = "/password/reset",
}
